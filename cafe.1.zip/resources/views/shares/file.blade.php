@extends('layouts.app')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                  <strong><a href="{{ route('shares.show', $share->id) }}">{{ $share->object->name() }}</a></strong>
                    Share
                </div>
                <div class="card-body">
                    <h4 class="card-header text-primary">
                        {{ $file->name }}
                        <br>
                        <small class="text-muted">
                            <i class="fa fa-caret-right"></i> size {{ $file->size() }}
                        </small>
                    </h4>
                    @if(App\Fun::canPlay($file))
                    <object width="100%" data="{{ asset('storage/'.$file->address) }}"></object>
                    @endif
                    <a class="btn btn-warning btn-sm" href="{{ asset('storage/'.$file->address) }}" download><i class="fa fa-download"></i> Download</a>
                </div>
            </div>
        </div>
    </div>
@endsection
