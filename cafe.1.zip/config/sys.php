<?php

return [
    'email_domain' => '@utg\.edu\.gm/i',

    'max_upload' => 500000000,
    'new_storage' => 100000000,
    'box_max_days' => 5,

    'can_play_extensions' => [
        'mp4',
        'mp3',
        'pdf',
        'jpg',
        'png',
    ],
];