<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use Illuminate\Support\Facades\Hash;
use App\Folder;

class OpenController extends Controller
{
    public function register(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users|regex:/(.*)'.config('sys.email_domain'),
        ]);

        $user = User::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'password' => Hash::make(str_random(10)),
            'storage' => config('sys.new_storage'),
        ]);

        Folder::create([
            'name' => 'Home',
            'user_id' => $user->id,
        ]);

        return view('auth.passwords.email', [
            'email' => $request['email'],
        ]);
    }
}
